package formas;

public class VariasFormas {


    private Forma[] formas;

    public VariasFormas(Forma[] formas) {
        this.formas = formas;
    }


    public void imprimirInformacionFormas() {

        for (int i = 0; i < formas.length; i++) {

            System.out.println(" f orma en la posicioon " + i + ":");
            formas[i].imprimir();

            System.out.println();
        }
    }

    public void cambiarColorFormas(String nuevoColor) {

        for (int i = 0; i < formas.length; i++) {

            formas[i].cambiarColor(nuevoColor);

            System.out.println(" forma en la posición " + i + " ahora tiene el color " + nuevoColor);
        }
    }

    public void calcularAreaMaxima() {
        if (formas.length == 0) {
            System.out.println(" no ay formas en el array.");
            return;
        }

        Forma formaMaxima = formas[0];
        double areaMaxima = calcularArea(formaMaxima);

        for (int i = 1; i < formas.length; i++) {
            double areaActual = calcularArea(formas[i]);
            if (areaActual > areaMaxima) {

                areaMaxima = areaActual;

                formaMaxima = formas[i];
            }
        }

        System.out.println("la forma con el area maxima es:");

        formaMaxima.imprimir();

        System.out.println("aarea maxima: " + areaMaxima);

    }

    private double calcularArea(Forma forma) {

        if (forma instanceof Rectangulo) {

            return ((Rectangulo) forma).calcularArea();

        } else if (forma instanceof Elipse) {

            return ((Elipse) forma).calcularArea();
        } else {
            return 0;
        }
    }
}