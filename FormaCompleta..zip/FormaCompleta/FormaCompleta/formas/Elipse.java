package formas;

class Elipse extends Forma {
    private double radioMayor;
    private double radioMenor;

    public Elipse(String color, Punto centro, String nombre, double radioMayor, double radioMenor) {
        super(color, centro, nombre);
        this.radioMayor = radioMayor;
        this.radioMenor = radioMenor;
    }

    @Override
    public void imprimir() {
        super.imprimir();

        System.out.println("Radio mayor: " + radioMayor);


        System.out.println("Radio menor: " + radioMenor);
    }

    public double calcularArea() {

        return Math.PI * radioMayor * radioMenor;
    }

    public void cambiarTamano(double factorEscala) {

        if (factorEscala > 0) {
            radioMayor *= factorEscala;

            radioMenor *= factorEscala;
        } else {
            System.out.println(" factor de escala debe > 0");
        }
    }

    public double getRadioMayor() {
        return radioMayor;
    }

    public void setRadioMayor(double radioMayor) {
        this.radioMayor = radioMayor;
    }

    public double getRadioMenor() {
        return radioMenor;
    }

    public void setRadioMenor(double radioMenor) {
        this.radioMenor = radioMenor;
    }

    @Override
    public String toString() {
        return "elipse{" +
                "nombre='" + getNombre() + '\'' +
                ", color='" + obtenerColor() + '\'' +
                ", centro=" + getCentro() +
                ", radioMayor=" + radioMayor +
                ", radioMenor=" + radioMenor +
                '}';
    }
}

