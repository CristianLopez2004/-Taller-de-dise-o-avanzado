package formas;

class Rectangulo extends Forma {
    private double ladoMenor;
    private double ladoMayor;

    public Rectangulo(String color, Punto centro, String nombre, double ladoMenor, double ladoMayor) {
        super(color, centro, nombre);
        this.ladoMenor = ladoMenor;
        this.ladoMayor = ladoMayor;
    }

    @Override
    public void imprimir() {
        super.imprimir();
        System.out.println("Lado menor: " + ladoMenor);
        System.out.println("Lado mayor: " + ladoMayor);
    }

    public double calcularArea() {
        return ladoMenor * ladoMayor;
    }

    public double calcularPerimetro() {
        return 2 * (ladoMenor + ladoMayor);
    }

    public void cambiarTamano(double factorEscala) {
        if (factorEscala > 0) {
            ladoMenor *= factorEscala;
            ladoMayor *= factorEscala;
        } else {
            System.out.println("factor de escala debe >> 0");
        }
    }

    public double getLadoMenor() {
        return ladoMenor;
    }

    public void setLadoMenor(double ladoMenor) {
        this.ladoMenor = ladoMenor;
    }

    public double getLadoMayor() {
        return ladoMayor;
    }

    public void setLadoMayor(double ladoMayor) {
        this.ladoMayor = ladoMayor;
    }

    @Override
    public String toString() {
        return "Rectangulo{" +
                "nombre='" + getNombre() + '\'' +
                ", color='" + obtenerColor() + '\'' +
                ", centro=" + getCentro() +
                ", ladoMenor=" + ladoMenor +
                ", ladoMayor=" + ladoMayor +
                '}';
    }
}