package formas;

import java.util.Scanner;


public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("inngrese el número de formas:");
        int numFormas = scanner.nextInt();

        scanner.nextLine();

        Forma[] formas = new Forma[numFormas];

        for (int i = 0; i < numFormas; i++) {

            System.out.println("seleccione el tipo de forma (1- Rectangulo, 2 - Cuadrado, 3- Elipse, 4- Circulo):");

            int tipo = scanner.nextInt();
            scanner.nextLine();

            System.out.println("ingrese el collor:");

            String color = scanner.nextLine();

            System.out.println("ingrese la coordenada X del centro:");

            double x = scanner.nextDouble();

            System.out.println("ingrese la coordenadaa Y del centro:");

            double y = scanner.nextDouble();
            scanner.nextLine();

            System.out.println("inngrese el nombre de la forma:");

            String nombre = scanner.nextLine();

            if (tipo == 1) {


                System.out.println("ingrese el lado menor del rectangulo:");

                double ladoMenor = scanner.nextDouble();

                System.out.println("Ingrese el lado mayor del rectaangulo:");

                double ladoMayor = scanner.nextDouble();


                scanner.nextLine();


                formas[i] = new Rectangulo(color, new Punto(x, y), nombre, ladoMenor, ladoMayor);
            } else if (tipo == 2) {
                System.out.println("ingrese el lado del cuadrado:");
                double lado = scanner.nextDouble();
                scanner.nextLine();  //

                formas[i] = new Cuadrado(color, new Punto(x, y), nombre, lado);
            } else if (tipo == 3) {
                System.out.println("ngrese el radio mayor de la elipse:");
                double radioMayor = scanner.nextDouble();

                System.out.println("ingrese el radio menor de la elipse:");
                double radioMenor = scanner.nextDouble();
                scanner.nextLine();

                formas[i] = new Elipse(color, new Punto(x, y), nombre, radioMayor, radioMenor);
            } else if (tipo == 4) {
                System.out.println("ingrese el radio del circulo:");
                double radio = scanner.nextDouble();
                scanner.nextLine();

                formas[i] = new Circulo(color, new Punto(x, y), nombre, radio);
            }
        }

        VariasFormas variasFormas = new VariasFormas(formas);

        boolean salir = false;
        while (!salir) {
            System.out.println("eleccione una opción:");

            System.out.println("1. Imprime la infoo de todas las formas");
            System.out.println("2. cambia el colo de todas las formas, depues imprima los datos de las formas");

            System.out.println("3. calcula area máxima");
            System.out.println("4. calcula área de una forma específica");
            System.out.println("5. calcula perímetro de un rectangulo o cuaadrado");

            System.out.println("6. cambiar tamaño de un rectaangulo, cuadrado, elipse o circulo");
            System.out.println("7. mover forma");

            System.out.println("8. sale");

            int opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    variasFormas.imprimirInformacionFormas();
                    break;
                case 2:
                    System.out.println("ponga el nuevo color :");

                    String nuevoColor = scanner.nextLine();

                    variasFormas.cambiarColorFormas(nuevoColor);
                    break;

                case 3:
                    variasFormas.calcularAreaMaxima();
                    break;
                case 4:
                    System.out.println("ngrese el indice de la forma:");

                    int indiceForma = scanner.nextInt();

                    scanner.nextLine();
                    if (indiceForma >= 0 && indiceForma < formas.length) {

                        Forma forma = formas[indiceForma];
                        if (forma instanceof Rectangulo) {
                            System.out.println("area: " + ((Rectangulo) forma).calcularArea());

                        } else if (forma instanceof Elipse) {

                            System.out.println("area: " + ((Elipse) forma).calcularArea());
                        } else {
                            System.out.println("forma imcompativle.");
                        }
                    } else {
                        System.out.println("innndice no es valido.");

                    }
                    break;
                case 5:
                    System.out.println("ingrese el indise de la forma:");
                    indiceForma = scanner.nextInt();

                    scanner.nextLine();
                    if (indiceForma >= 0 && indiceForma < formas.length) {

                        Forma forma = formas[indiceForma];
                        if (forma instanceof Rectangulo) {

                            System.out.println("Perímetro: " + ((Rectangulo) forma).calcularPerimetro());
                        } else {
                            System.out.println("Tipo de forma no compatible.");
                        }
                    } else {
                        System.out.println("ndice no es valido.");
                    }
                    break;
                case 6:
                    System.out.println("Ingrese el índice de la forma:");

                    indiceForma = scanner.nextInt();
                    scanner.nextLine();
                    if (indiceForma >= 0 && indiceForma < formas.length) {

                        System.out.println("ngrese el factor de escala:");
                        double factorEscala = scanner.nextDouble();

                        scanner.nextLine();
                        Forma forma = formas[indiceForma];


                        if (forma instanceof Rectangulo) {
                            ((Rectangulo) forma).cambiarTamano(factorEscala);
                        } else if (forma instanceof Elipse) {

                            ((Elipse) forma).cambiarTamano(factorEscala);
                        } else if (forma instanceof Circulo) {

                            ((Circulo) forma).cambiarTamano(factorEscala);

                        } else if (forma instanceof Cuadrado){

                            ((Cuadrado) forma).cambiarTamano(factorEscala);

                        }else {
                            System.out.println("tipo de forma no compativle.");
                        }
                    } else {
                        System.out.println("ndice no válido.");
                    }
                    break;

                case 7:

                    System.out.println("pongaindice de la forma:");

                    indiceForma = scanner.nextInt();
                    scanner.nextLine();

                    if (indiceForma >= 0 && indiceForma < formas.length) {

                        System.out.println("Ingrese la nueva coordenada x:");

                        double nuevaX = scanner.nextDouble();
                        System.out.println("Ingrese la nueva coordenada y:");

                        double nuevaY = scanner.nextDouble();
                        scanner.nextLine();

                        Forma forma = formas[indiceForma];


                        forma.moverForma(nuevaX, nuevaY);


                        System.out.println("forma movida a la nueva posición (" + nuevaX + ", " + nuevaY + ")");
                    } else {
                        System.out.println("ndice no es válido.");
                    }

                case 8:
                    salir = true;
                    break;
                default:

                    System.out.println("opcion no esvalida.");
                    break;
            }
        }

        scanner.close();
    }

}


