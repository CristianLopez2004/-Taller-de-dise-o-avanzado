package formas;

class Cuadrado extends Rectangulo {
    public Cuadrado(String color, Punto centro, String nombre, double lado) {
        super(color, centro, nombre, lado, lado);
    }

    @Override
    public void imprimir() {
        super.imprimir();
        System.out.println("cuadrado");
    }
}


