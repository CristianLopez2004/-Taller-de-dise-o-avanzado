package formas;

class Forma {
    private String color;
    private Punto centro;
    private String nombre;

    public Forma(String color, Punto centro, String nombre) {
        this.color = color;
        this.centro = centro;
        this.nombre = nombre;
    }

    public void imprimir() {
        System.out.println(this.toString());
    }

    public String obtenerColor() {
        return color;
    }

    public void cambiarColor(String color) {
        this.color = color;
    }

    public void moverForma(double nuevoX, double nuevoY) {
        this.centro.setX(nuevoX);
        this.centro.setY(nuevoY);
    }

    @Override
    public String toString() {
        return "Forma{" +
                "color='" + color + '\'' +
                ", centro=" + centro +
                ", nombre='" + nombre + '\'' +
                '}';
    }

    public Punto getCentro() {
        return centro;
    }

    public String getNombre() {
        return nombre;
    }
}
