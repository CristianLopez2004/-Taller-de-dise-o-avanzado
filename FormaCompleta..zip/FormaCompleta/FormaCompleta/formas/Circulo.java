package formas;

class Circulo extends Elipse {

    public Circulo(String color, Punto centro, String nombre, double radio) {

        super(color, centro, nombre, radio, radio);
    }

    @Override
    public void imprimir() {

        super.imprimir();


        System.out.println("circulo");
    }

    @Override
    public void cambiarTamano(double factorEscala) {
        if (factorEscala > 0) {
            super.cambiarTamano(factorEscala);

            double nuevoRadio = this.getRadioMayor();

            this.setRadioMayor(nuevoRadio);

            this.setRadioMenor(nuevoRadio);
        } else {

            System.out.println(" factor de escala debe >0");
        }
    }

    public double getRadio() {

        return this.getRadioMayor();
    }

    public void setRadio(double radio) {
        this.setRadioMayor(radio);

        this.setRadioMenor(radio);
    }

    @Override
    public String toString() {
        return "circulo{" +
                "nombre='" + getNombre() + '\'' +
                ", ccolor='" + obtenerColor() + '\'' +
                ", centro=" + getCentro() +
                ", radio=" + getRadio() +
                '}';
    }
}